__all__ = ["constants","escpos","exceptions","printer"]
